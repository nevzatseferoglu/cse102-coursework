#include <stdio.h>	
#include <math.h>	 /* for  calculations */	
#include <stdlib.h>  /* to generate pseudo number */
#include <time.h>	 /* to generate pseudo number */	
#define TRUE  1  	 /* for testing the condition */
#define FALSE 0
#define PI 	  3 			 /* constant pi number from math */

#define RED 0      			 /*Predefined colors*/
#define YELLOW 1
#define BLUE 2
#define BLACK 3
#define WHITE 4

#define SQUARE 1 			  /* Predefined Shape */		
#define RECTANGULAR 2
#define CIRCULAR 3

 double CreateBody (int);  
 int    SetColor(int);
 double LoadMoves(int,double);
 int    SetAttackPower(int, int);
 void   ShowPokemon(int,double,int,double,int);
 void   printfCircle(int); /* for purpose of printing circle pokémon on the screen*/
 
int main (void){
	int shape,color,attack_power;
	double size_of_body, move_length;

	shape=CIRCULAR; 	 /* SQUARE=1 / RECTANGULAR=2 / CIRCULAR=3 Pick one of them */						
	color=798;   					

	size_of_body = CreateBody (shape);
	color = SetColor(color);	/* Return valur will be for RED=0 / YELLOW=1 / BLUE= / BLACK=3 / WHITE=4 */
	move_length = LoadMoves(shape, size_of_body);
	attack_power = SetAttackPower (0,150); /*Range of Attack Power */
	ShowPokemon(shape, size_of_body, color, move_length,attack_power);

	return 0;
}
 double CreateBody (int shape)
 {
 	double edgeMagnitude=0,edgeMagnitude_2=0;
 	int controller=TRUE;
	 	if(shape==SQUARE){					/*for Creating Square Pokemon */												
	 		while(controller==TRUE){	 			/* thanks to while loop , user cannot type negative number or zero */							
	 		printf("Edge of Square Pokémon : ");
	 		scanf("%lf",&edgeMagnitude);
	 		if(edgeMagnitude>0)
	 			controller=FALSE;
	 		}
			edgeMagnitude=edgeMagnitude*edgeMagnitude;
	 		return edgeMagnitude;
	 	}
	 	else if (shape==RECTANGULAR) 									/*for Creating Rectancular Pokemon */
	 	{
	 		while(controller==TRUE){						/* thanks to while loop , user cannot type negative number or zero */
	 		printf("First edge of Rectancular Pokémon : ");
	 		scanf("%lf",&edgeMagnitude);
	 		if(edgeMagnitude>0)
	 			controller=FALSE;
	 		}
	 		controller=TRUE;	
	 		while(controller==TRUE){						/* thanks to while loop , user cannot type negative number or zero */
	 		printf("Second edge of Rectancular Pokémon : ");
	 		scanf("%lf",&edgeMagnitude_2);
	 		if(edgeMagnitude>0)
	 			controller=FALSE;
	 		}
	 		edgeMagnitude=edgeMagnitude*edgeMagnitude_2;
	 		return edgeMagnitude;
	 	}
	 	else if (shape==CIRCULAR){  	     							 /* for Creating Circular Pokemon */
	 		while(controller==TRUE){							 /* thanks to while loop , user cannot type negative number or zero */
	 		printf("Radius : ");
	 		scanf("%lf",&edgeMagnitude);
	 		if(edgeMagnitude>0)
	 			controller=FALSE;
	 		}
	 		edgeMagnitude=(PI)*(edgeMagnitude)*(edgeMagnitude);
	 		return edgeMagnitude;
	 	}
 }
 int SetColor(int color)				
 {	
 	if(color<=1000&&color>=0){					
 		color=color%5;					/* Setting Up the color */
 		return color;
 	}
 	else
 	return 1;
 }
 double LoadMoves(int shape,double size_of_body)
 {
 	int i=1,squareRoot,control;

 	if(shape==SQUARE){
 		return 4*sqrt(size_of_body);      /* Calculating region of square shape */
 	}
 	else if (shape==RECTANGULAR){     
 		squareRoot=sqrt(size_of_body); 		/* Calculating region of rectangular shape */
 		return (5*2+((size_of_body/5)*2));	
 	}
 	else if (shape==CIRCULAR){		
 		squareRoot=size_of_body/PI;	/* Calculating region of circular shape */
 		squareRoot=sqrt(squareRoot);
		squareRoot=2*PI*squareRoot;
		return squareRoot;		
 	}

 }
 int SetAttackPower(int lower_bound, int upper_bound)
 {
 	srand(time(NULL));
 	if(lower_bound<0||upper_bound<0||upper_bound==lower_bound){	 /* if color is in a range which is negative */
 		printf("There is wrong lower_bound or wrong upper_bound in the code!\n");
 		exit(1);
 	}
 	return rand() % (upper_bound - lower_bound + 1) + lower_bound;			
 }
 void ShowPokemon(int shape,double size_of_body,int color,double move_length,int attack_power)
 {
 		char colorStorage[5][24]={{"Red"},{"Yellow"},{"Blue"},{"Black"},{"White"}}; /* Array for colors */
 		char nameStorage[3][24]={{"Square Pokémon"},{"Rectengular Pokémon"},{"Circular Pokémon"}}; /*Array for Pokémon name*/
 		int i,j,temp;
 	if(shape==SQUARE)
 	{
 		temp=(int)sqrt(size_of_body);
 		for(i=0 ; i<temp ; ++i){
 			for(j=0 ; j<temp ; ++j){
 				printf("X");
 			}
 			printf("\n");
 		}
 	}
 	else if(shape==RECTANGULAR)
 	{
 		temp=(int)(size_of_body/5);
 		for(i=0 ; i<5 ; ++i){
 			for(j=0 ; j<temp ; ++j)
 			{
 				printf("X");
 			}
 			printf("\n");
 		}
 	}
 	else if(shape==CIRCULAR)
 	{
 		temp=(int)sqrt(size_of_body/3);
 		printfCircle(temp);
 	}
 	printf("\n");
 	printf("Name : %s  \n",nameStorage[shape-1]);
 	printf("Size : %.2lf \n",size_of_body);
 	printf("Color: %s \n",colorStorage[color]);
 	printf("Move : %.2lf \n",move_length);
 	printf("Attack Power: %d\n",attack_power);
 }
 void printfCircle(int r){
	int i,j;
	int exterior=(r-1)/2;     /*I have divided in two parts for printing the circular as even number or odd number*/
	int interior=2;

	if(r%2!=0){
		for(i=1 ; i<=(r-1)/2 ; ++i){		/* counter for amoutn of line */
			for(j=1 ; j<=exterior ; ++j){
				printf("%c",'\t');
			}
			--exterior;	
			if(i==1){
			printf("X\n");
			}
			else{
				printf("X");
				for(j=1 ; j<=interior ; ++j)
				{
				printf("%c",'\t');
				}
				printf("X\n");
				interior=interior+2;
			}
		}

		printf("X");
		for(j=1 ; j<=interior ; ++j){
		printf("%c",'\t');
		}
		printf("X\n");

		exterior=1;
		interior=(r-1)-2;
		
		for(i=(r-1)/2 ; i>=1 ; --i){
			for(j=1 ; j<=exterior ; ++j){
				printf("%c",'\t');
			}
			++exterior;	
			if(i==1){
			printf("X\n");
			}
			else{
				printf("X");
				for(j=interior ; j>=1 ; --j)
				{
				printf("%c",'\t');
				}
				printf("X\n");
				interior=interior-2;
			}
		}
    }

    else{
		exterior=(r)/2; 
		interior=1;

			for(i=1 ; i<=r/2 ; ++i){
				if(i==1){
					for(j=1 ; j<=exterior-1 ; ++j){
						printf("%c",'\t');
					}
					for(j=1 ; j<=4 ;++j){
						printf("%c",' ');
					}
					printf("X\n");
				}
				else{
					for(j=1 ; j<=exterior-1 ; ++j){
						printf("%c",'\t');
					}
						printf("X");
					for(j=1 ; j<=interior ; ++j){
						printf("%c",'\t');
						}
						printf("X\n");
						interior=interior+2;
					
					--exterior;	
					}
			}
		
		printf("X");
		for(j=1 ; j<=r-1 ; ++j){
		printf("%c",'\t');
		}
		printf("X\n");
		
		exterior=1;
		interior=(r-1)-2;

		for(i=(r/2) ; i>=1 ; --i){
				if(i==1){
					for(j=1 ; j<=(r/2)-1 ; ++j){
					printf("%c",'\t');
					}
					for(j=1 ; j<=4 ;++j){
						printf("%c",' ');
					}
					printf("X\n");
				}
				else{
					for(j=1 ; j<=exterior ; ++j){
						printf("%c",'\t');
					}
					printf("X");
					for(j=1 ; j<=interior ; ++j){
						printf("%c",'\t');
					}
						printf("X\n");

					++exterior;
					interior=interior-2;
			}
		}	
	}
}