#include <stdio.h>
#include <stdlib.h>
#include <time.h>
/*---------NEVZAT SEFEROGLU ----- */
/*171044024-2018 GTU COMPUTER PROGAMMING 102  */
/* POKÉMON GAMES 							  */
/*--------------------------------------------*/
#define	P_NUM 10
#define clear() printf("\033[H\033[J") /*for cleaning the terminal*/ 

typedef enum {Charmander,Pikachu,Squirtle,Bulbasaur,Pidgeotto,Ratata,Mug,Caterpie,Zubat,Krabby}pokemon;
typedef enum {quadratic,linear}attack_type;

void pokedex(char Pokemon_name[][11], int range[],attack_type type[],int attack_power[], int stamina[]); /* pokedex function */ 
/* menu function */
void menu();
/* menu function */
void oakMenu();
int str_cmp(char *strA,char *strB);
/* str_cmp function. I wrote on my own*/
void oaks_laboratory(char Pokemon_name[][11], pokemon Pokemons[10],pokemon *my_Pokemons);
void show_Pokemons(char Pokemon_name[][11], pokemon Pokemons[10],int pokemon_count);
void catch_a_pokemon(char Pokemon_name[][11],pokemon Pokemons[10],pokemon *my_pocket);
void release_a_pokemon(char Pokemon_name[][11],pokemon Pokemons[10],pokemon *my_pocket);

void attackPokemon(int x,int y,int area[8][8],char Pokemon_name[][11],int range[],attack_type type[],int attack_power[],int pokemon_staminas_view[8][8],int i);

int areaControl(int x,int y,int area[8][8],int block,int way);
void show_area (char Pokemon_name[][11],int area[8][8],int pokemon_staminas_view[8][8]);
void battle(char Pokemon_name[][11],int range[], attack_type type[], int attack_power[], int stamina[], pokemon user_Pokemons[]);

int main()
{
	srand(time(NULL));
	menu();
	return 0;
}
void pokedex(char Pokemon_name[][11], int range[], attack_type type[],int attack_power[], int stamina[])
{
	pokemon pName; /* enumarate structure */
	int pass=1,i=0;
	char tempName[11]={'\0'};
	printf("Please type name of the Pokémon (type exit to close Pokedex):");
	scanf("%s",tempName);
	while(str_cmp(tempName,"exit")!=0)
	{
		clear();
		while(pName<P_NUM&&pass)	 /* Control the pokomon Name exist or not  */
		{			
			if((str_cmp(tempName,Pokemon_name[pName]))==0)
				pass=0;
			++pName;
		}
		pName=pName-1;
		if(pass==1)
		{
			printf("There is no Pokémon by this name ! Try Again Please \n");
		}
		else
		{
			printf("Name     :%s\n",tempName);
			printf("A.Type   :");
			if(type[pName]==quadratic) printf("Quadratic\n");
			else 			 	   	   printf("Linear\n");
			printf("Range    :%d\n",range[pName]);
			printf("A. Power :%d\n",attack_power[pName]);
			printf("Stamina  :%d\n\n\n",stamina[pName]);
		}
		printf("Please type name of the Pokémon (type exit to close Pokedex):");
		scanf("%s",tempName);
		pass=1;
		pName=0;
	}
}
void menu()
{
	clear();
	/*...........Some filling Operation .......*/
	char pokemonName[P_NUM+1][11]={{"Charmander"},{"Pikachu"},{"Squirtle"},{"Bulbasaur"},{"Pidgeotto"},{"Ratata"},{"Mug"},{"Caterpie"},{"Zubat"},{"Krabby"},{"EMPTY"}};
	attack_type type[10]={quadratic,linear,linear,linear,quadratic,linear,quadratic,quadratic,linear,linear};
	pokemon Pokemons[10]={Charmander,Pikachu,Squirtle,Bulbasaur,Pidgeotto,Ratata,Mug,Caterpie,Zubat,Krabby};
	pokemon my_Pokemons[4]={10,10,10,10};
	int attack_power[P_NUM]={500,350,300,400,250,250,350,200,350,300};
	int range[P_NUM]={1,3,4,3,2,2,1,2,3,2};
	int stamina[P_NUM]={2200,1500,1700,2500,1900,2500,3000,1200,1250,2600};
	int quit=1,counter=0,i=0;
	/*...........Some filling Operation .......*/
	int choice=-1;
	while(quit)
	{
		while(choice<1||choice>4)
		{	
		//	clear();
			printf("1-) Open Pokedex\n"); 
			printf("2-) Go to Oak’s Laboratory\n");
			printf("3-) Enter the Tournament\n");
			printf("4-) Exit Game\n");
			printf("Choice : ");
			scanf(" %d",&choice);
		}
		switch(choice)		/* Control With Switch Statement */
		{
			case 1:
				clear();
				pokedex(pokemonName,range,type,attack_power,stamina);
			break;

			case 2:
				clear();
				oaks_laboratory(pokemonName,Pokemons,my_Pokemons);
			break;

			case 3:
				for(i=0 ; i<4 ; ++i)
				{
				 	if(my_Pokemons[i]!=10)
				 	++counter;	
				}
				if(counter==4)
				{
					battle(pokemonName,range,type,attack_power,stamina,my_Pokemons);
					quit=0;
				}
				else
				{
					clear();
					printf("You have not enough Pokemon to attend the tournament !\n");
					printf("You can catch the pokemon with Oak Laboratory !\n");
					counter=0;
				}
			break;

			case 4:
				quit=0;
			break;
		}
			choice=-1;	
	}
}
void oaks_laboratory(char Pokemon_name[][11], pokemon Pokemons[10],pokemon *my_Pokemons)
{
	int choice=-1,i=0,exit=1;
	int pokemon_count=0;
	while(exit)
	{	
		while(choice<1||choice>5)
		{
			printf("Welcome to Laboratory of Professor Oak. How can I help you?\n");
			printf("  1-) Show Pokémons\n");
			printf("  2-) Catch a Pokémon\n");
			printf("  3-) Release a Pokémon\n");
			printf("  4-) Show My Pocket\n");
			printf("  5-) Back\n");
			printf("Choice:");
			scanf(" %d",&choice);
			clear();
		}
		clear();
		
		switch(choice)		/* Control With Switch Statement */
		{
			case 1:
				pokemon_count=10;
				show_Pokemons(Pokemon_name,Pokemons,pokemon_count);
			break;

			case 2:
				catch_a_pokemon(Pokemon_name,Pokemons,my_Pokemons);
			break;

			case 3:
				release_a_pokemon(Pokemon_name,Pokemons,my_Pokemons);
			break;

			case 4:
				pokemon_count=4;
				show_Pokemons(Pokemon_name,my_Pokemons,pokemon_count);
			break;

			case 5:
				exit=0;
			break;
		}

		choice=-1;
		pokemon_count=0;
	}
	exit=1;
}
void show_Pokemons(char Pokemon_name[][11], pokemon Pokemons[],int pokemon_count)
{
	int i=0;
	pokemon counter;
	if(pokemon_count==10)							/* Control With If Else Statement */
	{
		for(counter=0 ; counter<pokemon_count ; ++counter)
		printf("%d - %s \n",counter,Pokemon_name[counter]);
	}
	else
	{
		printf("Current Pocket Condition : \n\n");
		for(i=0 ; i<4 ; ++i)
		{
			printf("Slot (%d)  -------> %s  \n\n",i+1,Pokemon_name[Pokemons[i]]);
		}
	}
	printf("\n");
}
void catch_a_pokemon(char Pokemon_name[][11],pokemon Pokemons[10],pokemon *my_pocket)
{
	int tempIds=0,i=0,counter=0,pokemon_count=10,j=0;
	int empy_Location[4]={10,10,10,10};
	for(i=0 ; i<4 ; ++i)
	{
		if(my_pocket[i]==10)
		{
			empy_Location[j]=i;
			printf("\t\t\t**Attention Please !**\n");
			printf("**Rules** : \n");
			printf("--> You cannot choose more than four pokémons.\n");
			printf("--> You cannot choose more than one type of same pokémons.\n");
			printf("--> You can catch the pokémons with entering the its own special ids number.\n\n");
			printf("--> Lets Start !\n\n");
			show_Pokemons(Pokemon_name,Pokemons,pokemon_count);
			printf("Ids Number : ");
			scanf("%d",&tempIds);
			while(tempIds<0||tempIds>9)
			{
				printf("Entered Wrong Ids Number ! Try Again \n");
				printf("Ids Code : ");
				scanf("%d",&tempIds);	/* Taking Ideas Number */
				clear();
			}
			for(i=0 ; i<4 ; ++i)
			{
				while(my_pocket[i]==tempIds) 	/* Controlling Ids Number */
				{
					printf("%s has been already catched before ! Catch Another One\n",Pokemon_name[tempIds]);
					printf("Ids Number : ");
					scanf("%d",&tempIds);
					while(tempIds<0||tempIds>9)
					{
						printf("Entered Wrong Ids Number ! Try Again \n");
						printf("Ids Code : ");
						scanf("%d",&tempIds);
						clear();
					}
					i=0;
				}
			}
			my_pocket[empy_Location[j]]=tempIds;
			clear();
			printf("*** %s is catched successfully !***\n\n",Pokemon_name[tempIds]);	
			++j;
		}
		else
			++counter;
	}
	if(counter==4)
		printf("*****  Pocket is full ! ***** \n\n");	
}
void release_a_pokemon(char Pokemon_name[][11],pokemon Pokemons[10],pokemon *my_pocket)
{

	int tempRl=0,pokemon_count=4;
	printf("\t\t\t**Attention Please !**\n");
	printf("**Rules** : \n");
	printf("--> You cannot release more than one time.\n");
	printf("--> You can release the pokémons with entering their slot number \n");
	printf("--> Lets Start ! \n\n");

	show_Pokemons(Pokemon_name,my_pocket,pokemon_count);

	printf("Slot Code : ");
	scanf("%d",&tempRl);		/*...Taking Slot Code ....*/
	while(tempRl<1||tempRl>4)
	{
		printf("Entered Wrong Slot Code ! Try Again \n");
		printf("Slot Code : ");
		scanf("%d",&tempRl);
	}
	clear();
	if(my_pocket[tempRl-1]==10)
		printf("**You cannot release the pokémons from the empy slot ! **\n\n");
	else
	{
		printf("%s has been released from the --> Slot (%d) <-- \n\n",Pokemon_name[my_pocket[tempRl-1]],tempRl);
		my_pocket[tempRl-1]=10;
	}
}
void battle(char Pokemon_name[][11], int range[], attack_type type[], int attack_power[], int stamina[], pokemon user_Pokemons[])
{
	pokemon randomArr;
	int x=0,y=0;
	int i=0,j=0,t=0,k=0,pass=1,a=0,b=0,c=0,d=0,tempRandom=0,randomBlock=0,randomWay=0;
	char tempPokemon[11]={0};
	int block=0,way=0,pokemon=-1,pokemonStamina=-1;
	int randomLocation[4][2]={
		{-1,-1},						/* Filling with '-1' to control in forward side of program code*/
		{-1,-1},
		{-1,-1},
		{-1,-1},
	};
	int location[4][2]={
		{-1,-1},						/* Filling with '-1' to control in forward side of program code*/
		{-1,-1},
		{-1,-1},
		{-1,-1},
	};
	int area[8][8]={
		{-1,-1,-1,-1,-1,-1,-1,-1},		/* Filling with '-1' to control in forward side of program code*/
		{-1,-1,-1,-1,-1,-1,-1,-1},
		{-1,-1,-1,-1,-1,-1,-1,-1},		
		{-1,-1,-1,-1,-1,-1,-1,-1},
		{-1,-1,-1,-1,-1,-1,-1,-1},
		{-1,-1,-1,-1,-1,-1,-1,-1},
		{-1,-1,-1,-1,-1,-1,-1,-1},
		{-1,-1,-1,-1,-1,-1,-1,-1}
	};
	int pokemon_staminas_view[8][8]={
		{-1,-1,-1,-1,-1,-1,-1,-1},		/* Filling with '-1' to control in forward side of program code*/
		{-1,-1,-1,-1,-1,-1,-1,-1},
		{-1,-1,-1,-1,-1,-1,-1,-1},
		{-1,-1,-1,-1,-1,-1,-1,-1},
		{-1,-1,-1,-1,-1,-1,-1,-1},
		{-1,-1,-1,-1,-1,-1,-1,-1},
		{-1,-1,-1,-1,-1,-1,-1,-1},
		{-1,-1,-1,-1,-1,-1,-1,-1},
	};

	printf("\t\t\t***Welcome to the Pokémon Tournament***\n");
	printf("**Rules : \n");
	printf("If You want to locate the pokemon for starting the tournament, you have to enter the coordinate that you want to locate.\n");
	printf("To move the Pokémon type the coordinate of the pokémon which you want to move.\n");

	printf("Good Luck !\n\n\n");

	show_area (Pokemon_name,area,pokemon_staminas_view);
	for(i=0 ; i<4 ; ++i)
	{
		printf("%s \n",Pokemon_name[user_Pokemons[i]]);
		printf("Row Code (Locating): ");
		scanf("%d",&location[i][0]);
		while(location[i][0]!=1&&location[i][0]!=0)
		{
			printf("You can only use first two rows to locate ! \n");
			printf("Row Code (Locating): ");
			scanf("%d",&location[i][0]);
		}
		printf("Column Code (Locating): ");
		scanf("%d",&location[i][1]);
		while(location[i][1]<0||location[i][1]>7)
		{
			printf("Wrong Column Code !\n");
			printf("Column Code (Locating):");
			scanf("%d",&location[i][1]);
		} 

		while(area[location[i][0]][location[i][1]]!=-1)
		{
			printf("This Location is not Empty ! \n");
			printf("%s \n",Pokemon_name[user_Pokemons[i]]);
			printf("Row Code (Locating): ");
			scanf("%d",&location[i][0]);
			while(location[i][0]!=1&&location[i][0]!=0)
			{
				printf("You can only use first two rows to locate ! \n");
				printf("Row Code (Locating):");
				scanf("%d",&location[i][0]);
			}
			printf("Column Code (Locating): ");
			scanf("%d",&location[i][1]);
			while(location[i][1]<0||location[i][1]>7)
			{
				printf("Wrong Column Code !\n");
				printf("Column Code (Locating): ");
				scanf("%d",&location[i][1]);
			}
		}
		area[location[i][0]][location[i][1]]=user_Pokemons[i];
		pokemon_staminas_view[location[i][0]][location[i][1]]=stamina[user_Pokemons[i]];
	}

		for(i=0 ; i<4 ; ++i)
		{
			/*	.............OPERATION FOR RANDOM POKEMON MOVEMENT................ 	 */

			randomLocation[i][0]=rand()%8;

			while(randomLocation[i][0]!=6&&randomLocation[i][0]!=7)
			{
				randomLocation[i][0]=rand()%8;
			}

			randomLocation[i][1]=rand()%8;

			while(randomLocation[i][1]<0||randomLocation[i][1]>7)
			{
				randomLocation[i][1]=rand()%8;
			}
			
			while(area[randomLocation[i][0]][randomLocation[i][1]]!=-1)
			{
				randomLocation[i][0]=rand()%8;

				while(randomLocation[i][0]!=6&&randomLocation[i][0]!=7){
					 randomLocation[i][0]=rand()%8;
					}

				randomLocation[i][1]=rand()%8;

				while(randomLocation[i][1]<0||randomLocation[i][1]>7){
					 randomLocation[i][1]=rand()%8;
					}
			}
			randomArr=rand()%10; 
			area[randomLocation[i][0]][randomLocation[i][1]]=randomArr;
			pokemon_staminas_view[randomLocation[i][0]][randomLocation[i][1]]=stamina[randomArr];
		}
		clear();
		show_area (Pokemon_name,area,pokemon_staminas_view);

		i=0;
		while(1)
		{
			if(i%2==0)
			{	
				/*..... Taking Pokemon Coordinate .......*/
				
				printf("Pokemon Coordinate(moving) : \n");
				printf("x=");
				scanf("%d",&x);
				printf("y=");
				scanf("%d",&y);
				while(area[x][y]==-1)
				{
					/*..... Taking True Adress With While Loop .......*/
					printf("Invalid Pokemon Coordinate ! \n");
					printf("x= ");
					scanf("%d",&x);
					printf("y= ");
					scanf("%d",&y);
				}
				while(pass==1&&area[x][y]!=-1)
				{
					for(t=0 ; t<4 &&pass; ++t)
					{
						if(area[x][y]==area[location[t][0]][location[t][1]])
						{
							pass=0;
						}
					}
					if(pass==1)
					{
						printf("Invalid Pokemon Coordinate ! \n");
						printf("x= ");
						scanf("%d",&x);
						printf("y= ");
						scanf("%d",&y);
					}
				}
				printf("Selected Pokémon : %s\n",Pokemon_name[area[x][y]]);
				
				/*..........Reaction with ids Number of Pokemon......................*/
			
				--t;
				pass=1;

				pokemon=area[x][y];
				pokemonStamina=pokemon_staminas_view[x][y];
				
				area[x][y]=-1;
				pokemon_staminas_view[x][y]=-1;

				way=-1;
				while(areaControl(x,y,area,block,way)<0)
				{
					printf("Choose Way : ");
					scanf("%d",&way);
					while(way!=1&&way!=2&&way!=3&&way!=4&&way!=5)
					{
						printf("Choose Way : ");
						scanf("%d",&way);
					}
					printf("How many block do you want to move (1) or (2) : ");
					scanf("%d",&block);
					while(block!=1&&block!=2)
					{
						printf("How many block do you want to move (1) or (2) : ");
						scanf("%d",&block);
					}
				}
				if(areaControl(x,y,area,block,way)>0&&block==1)
				{
					if(way==1)
						x=x-1;
					if(way==2)
						y=y-1;
					if(way==3)		/* Sending To the areaControl whether function is empty or not */
						x=x+1;
					if(way==4)
						y=y+1;
					if(way==5)
						x=x;
				}
				else if(areaControl(x,y,area,block,way)>0&&block==2)
				{
					if(way==1)
						x=x-2;

					if(way==2)
						y=y-2;

					if(way==3)		/* Sending To the areaControl whether function is empty or not */
						x=x+2;

					if(way==4)
						y=y+2;
					if(way==5)
						x=x;
				}
				location[t][0]=x;
				location[t][1]=y;

				area[x][y]=pokemon;
			    pokemon_staminas_view[x][y]=pokemonStamina; 

				attackPokemon(x,y,area,Pokemon_name,range,type,attack_power,pokemon_staminas_view,i);
				clear();
				show_area (Pokemon_name,area,pokemon_staminas_view);

			    pokemon=-1;
			    pokemonStamina=-1;
			}
			else
			{
				/*	.............OPERATION FOR RANDOM POKEMON MOVEMENT................*/

				tempRandom=rand()%4;
				if(tempRandom==0){
				x=randomLocation[0][0];
				y=randomLocation[0][1];
				}
				else if(tempRandom==1){
				x=randomLocation[1][0];
				y=randomLocation[1][1];
				}
				else if(tempRandom==2){
				x=randomLocation[2][0];
				y=randomLocation[2][1];
				}
				else if(tempRandom==3){
				x=randomLocation[3][0];
				y=randomLocation[3][1];
				}
				pokemon=area[x][y];
				pokemonStamina=pokemon_staminas_view[x][y];
				
				area[x][y]=-1;
				pokemon_staminas_view[x][y]=-1;

				randomWay=-1;
				while(areaControl(x,y,area,randomBlock,randomWay)<0)
				{
					randomWay=(rand()%5)+1;
					randomBlock=(rand()%2)+1;
				}

				if(areaControl(x,y,area,randomBlock,randomWay)>0&&randomBlock==1)
				{
					if(randomWay==1)
						x=x-1;
					if(randomWay==2)
						y=y-1;
					if(randomWay==3)
						x=x+1;
					if(randomWay==4)
						y=y+1;
					if(randomWay==5)
						x=x;
				}
				else if(areaControl(x,y,area,randomBlock,randomWay)>0&&randomBlock==2)
				{
					if(randomWay==1)
						x=x-2;

					if(randomWay==2)
						y=y-2;

					if(randomWay==3)
						x=x+2;

					if(randomWay==4)
						y=y+2;
					if(randomWay==5)
						x=x;
				}

				area[x][y]=pokemon;
			    pokemon_staminas_view[x][y]=pokemonStamina;

			/*	.............OPERATION FOR RANDOM POKEMON MOVEMENT................ 	 */
			
			    attackPokemon(x,y,area,Pokemon_name,range,type,attack_power,pokemon_staminas_view,i);
			    clear();
				show_area (Pokemon_name,area,pokemon_staminas_view);
			    pokemon=-1;
			    pokemonStamina=-1;
				if(tempRandom==0){
				randomLocation[0][0]=x;
				randomLocation[0][1]=y;
				}
				else if(tempRandom==1){
				randomLocation[1][0]=x;
				randomLocation[1][1]=y;
				}
				else if(tempRandom==2){
				randomLocation[2][0]=x;
				randomLocation[2][1]=y;
				}
				else if(tempRandom==3){
				randomLocation[3][0]=x;
				randomLocation[3][1]=y;
				}
			}
		    ++i;
		    x=0;
		    y=0;
		}
}
int areaControl(int x,int y,int area[8][8],int block,int way)
{
	/*....... Border Coordinate of The Table ............*/
	if((x==0&&y==0||x==1&&y==0||x==2&&y==0||x==3&&y==0||x==4&&y==0||x==5&&y==0||x==6&&y==0||x==7&&y==0)&&way==2)
		return -1;
	else if((x==0&&y==0||x==0&&y==1||x==0&&y==2||x==0&&y==3||x==0&&y==4||x==0&&y==5||x==0&&y==6||x==0&&y==7)&&way==1)
		return -1;
	else if((x==7&&y==0||x==7&&y==1||x==7&&y==2||x==7&&y==3||x==7&&y==4||x==7&&y==5||x==7&&y==6||x==7&&y==7)&&way==3)
		return -1;
	else if((x==0&&y==7||x==1&&y==7||x==2&&y==7||x==3&&y==7||x==4&&y==7||x==5&&y==7||x==6&&y==7||x==7&&y==7)&&way==4)
		return -1;
	else if(way<0)
		return -1;
	/*---------------End----------------------------------*/

	/*---------------Beginning of The Control Statement ----------------------------------*/
	if(way==1&&block==1)
	{
		if(area[x-1][y]==-1)
			return 1;
		else
			return -1;
	}
	if(way==2&&block==1)
	{
		if(area[x][y-1]==-1)
			return 1;
		else
			return -1;
		
	}
	if(way==3&&block==1)
	{
		if(area[x+1][y]==-1){
			return 1;
		}
		else
			return -1;
	}
	if(way==4&&block==1)
	{
		if(area[x][y+1]==-1)
			return 1;
		else
			return -1;	
	}
	if(way==5&&block==1)
	{
		return 1;
	}

	if(way==1&&block==2)
	{
		if((x-2)<0||(x-2)>7)
			return -1;
		else if(area[x-2][y]==-1)
			return 1;
		else
			return -1;
	}
	if(way==2&&block==2)
	{
		if((y-2)<0||(y-2)>7)
			return -1;
		else if(area[x][y-2]==-1)
			return 1;
		else
			return -1;
		
	}
	if(way==3&&block==2)
	{
		if((x+2)<0||(x+2)>7)
			return -1;
		else if(area[x+2][y]==-1)
			return 1;
		else
			return -1;
	}
	if(way==4&&block==2)
	{
		if((y+2)<0||(y+2)>7)
			return -1;
		else if(area[x][y+2]==-1)
			return 1;
		else
			return -1;	
	}
	if(way==5&&block==2)
	{
		return 1;
	}
	return -1;
	/*---------------End----------------------------------*/
}
void attackPokemon(int x,int y,int area[8][8],char Pokemon_name[][11],int range[],attack_type type[],int attack_power[],int pokemon_staminas_view[8][8],int k)
{
	int i=0,j=0;
	/*---------------Attack the Area I think that  I am dealing with Rectangular Area----------------------------------*/
	if(type[area[x][y]]==quadratic&&range[area[x][y]]==1)
	{
		for(i=x-1 ; i<=x+1 ; ++i)
		{
			for(j=y-1 ; j<=y+1 ; ++j)
			{
				if(i!=x&&j!=y)
					if((area[i][j]!=-1)&&(i>=0)&&(j>=0)&&(i<8)&&(j<8)&&(i!=x&&j!=y))
					{
						if(k%2==0)
						printf("You have attacked to  %s   ! \n",Pokemon_name[area[i][j]]);
						else if(k%2==1&&area[i][j])
						printf("AI has attacked to your %s ! \n",Pokemon_name[area[i][j]]);
						
						pokemon_staminas_view[i][j]=pokemon_staminas_view[i][j]-attack_power[area[x][y]];

						if(pokemon_staminas_view[i][j]<=0)
						{
							area[i][j]=-1;
							pokemon_staminas_view[i][j]=-1;
						}
					}
			}
		}
	}
	/*-------------End----------------------------------*/
	/*---------------Attack the Area I think that  I am dealing with Rectangular Area----------------------------------*/
	else if(type[area[x][y]]==quadratic&&range[area[x][y]]==2)
	{
		for(i=x-2 ; i<=x+2 ; ++i)
		{
			for(j=y-2 ; j<=y+2 ; ++j)
			{
				if(area[i][j]!=-1&&i!=x&&j!=y&&i>=0&&j>=0)
				{
					if(k%2==0)
					printf("You have attacked to  %s \n !",Pokemon_name[area[i][j]]);
					else
					printf("AI has attacked to your   %s \n !",Pokemon_name[area[i][j]]);

					pokemon_staminas_view[i][j]=pokemon_staminas_view[i][j]-attack_power[area[x][y]];
					printf("%d\n",pokemon_staminas_view[i][j]);
					if(pokemon_staminas_view[i][j]<=0)
					{
						area[i][j]=-1;
						pokemon_staminas_view[i][j]=-1;
					}
				}
			}
		}
	}
	/*-------------End----------------------------------*/
	/*---------------Attack the Area I think that  I am dealing with Rectangular Area----------------------------------*/
	else if (type[area[x][y]]==quadratic&&range[area[x][y]]==3)
	{
		for(i=x-3 ; i<=x+3 ; ++i)
		{
			for(j=y-3 ; j<=y+3 ; ++j)
			{
				if(area[i][j]!=-1&&i!=x&&j!=y&&i>=0&&j>=0) // area[i][j]!=-1&&area[i][j]<10&&area[i][j]>-1&&i!=x&&j!=y
				{
					if(k%2==0)
					printf("You have attacked to  %s \n !",Pokemon_name[area[i][j]]);
					else
					printf("AI has attacked to your   %s \n !",Pokemon_name[area[i][j]]);
					pokemon_staminas_view[i][j]=pokemon_staminas_view[i][j]-attack_power[area[x][y]];
					printf("%d\n",pokemon_staminas_view[i][j]);
					if(pokemon_staminas_view[i][j]<=0)
					{
						area[i][j]=-1;
						pokemon_staminas_view[i][j]=-1;
					}
				}
			}
		}
		
	}
	/*-------------End----------------------------------*/
	/*--------------- Linear Attack Arranging----------------------------------*/
	else if(type[area[x][y]]==linear&&range[area[x][y]]==1)
	{
		if(area[x][y-1]!=-1)
		{
			if(k%2==0)
				printf("You have attacked to  %s \n !",Pokemon_name[area[i][j]]);
			else
			printf("AI has attacked to your   %s \n !",Pokemon_name[area[i][j]]);

			pokemon_staminas_view[x][y-1]=pokemon_staminas_view[x][y-1]-attack_power[area[x][y]];
			if(pokemon_staminas_view[x][y-1]<=0)
			{
				area[x][y-1]=-1;
				pokemon_staminas_view[x][y-1]=-1;
			}
		}
		if(area[x-1][y]!=-1)
		{
			if(k%2==0)
			printf("You have attacked to  %s  ! \n",Pokemon_name[area[x-1][y]]);
			else
			printf("AI has attacked to your %s ! \n",Pokemon_name[area[x][y-1]]);

			pokemon_staminas_view[x-1][y]=pokemon_staminas_view[x-1][y]-attack_power[area[x][y]];
			if(pokemon_staminas_view[x-1][y]<=0)
			{
				area[x-1][y]=-1;
				pokemon_staminas_view[x-1][y]=-1;
			}
		}
		if(area[x][y+1]!=-1)
		{
			if(k%2==0)
				printf("You have attacked to  %s ! \n",Pokemon_name[area[x][y+1]]);
			else
			printf("AI has attacked to your %s   ! \n",Pokemon_name[area[x][y-1]]);

			pokemon_staminas_view[x][y+1]=pokemon_staminas_view[x][y+1]-attack_power[area[x][y]];
			if(pokemon_staminas_view[x][y+1]<=0)
			{
				area[x][y+1]=-1;
				pokemon_staminas_view[x][y+1]=-1;
			}
		}
		if(area[x+1][y]!=-1)
		{
			if(k%2==0)
			printf("You have attacked to  %s   ! \n ",Pokemon_name[area[x+1][y]]);
			else
			printf("AI has attacked to your %s ! \n",Pokemon_name[area[x][y-1]]);

			pokemon_staminas_view[x+1][y]=pokemon_staminas_view[x+1][y]-attack_power[area[x][y]];
			if(pokemon_staminas_view[x+1][y]<=0)
			{
				area[x+1][y]=-1;
				pokemon_staminas_view[x+1][y]=-1;
			}
		}
		i=0;
	}
	/*-------------End----------------------------------*/
	/*--------------- Linear Attack Arranging----------------------------------*/
	else if(type[area[x][y]]==linear&&range[area[x][y]]==2)
	{
		if(area[x][y-2]!=-1)
		{
			if(k%2==0)
			printf("You have attacked to  %s   ! \n ",Pokemon_name[area[x][y-2]]);
			else
			printf("AI has attacked to your %s ! \n",Pokemon_name[area[x][y-1]]);

			pokemon_staminas_view[x][y-2]=pokemon_staminas_view[x][y-2]-attack_power[area[x][y]];
			if(pokemon_staminas_view[x][y-2]<=0)
			{
				area[x][y-2]=-1;
				pokemon_staminas_view[x][y-2]=-1;
			}
		}
		if(area[x-2][y]!=-1)
		{
			if(k%2==0)
				printf("You have attacked to  %s \n !",Pokemon_name[area[x-2][y]]);
			else
			printf("AI has attacked to your   %s \n !",Pokemon_name[area[x][y-1]]);

			pokemon_staminas_view[x-2][y]=pokemon_staminas_view[x-2][y]-attack_power[area[x][y]];
			if(pokemon_staminas_view[x-2][y]<=0)
			{
				area[x-2][y]=-1;
				pokemon_staminas_view[x-2][y]=-1;
			}
		}
		if(area[x][y+2]!=-1)
		{
			if(k%2==0)
			printf("You have attacked to  %s 	\n !",Pokemon_name[area[x][y+2]]);
			else
			printf("AI has attacked to your %s  \n !",Pokemon_name[area[x][y-1]]);

			pokemon_staminas_view[x][y+2]=pokemon_staminas_view[x][y+2]-attack_power[area[x][y]];
			if(pokemon_staminas_view[x][y+2]<=0)
			{
				area[x][y+2]=-1;
				pokemon_staminas_view[x][y+2]=-1;
			}
		}
		if(area[x+2][y]!=-1)
		{
			if(k%2==0)
			printf("You have attacked to  %s   \n !",Pokemon_name[area[x+2][y]]);
			else
			printf("AI has attacked to your %s \n !",Pokemon_name[area[x][y-1]]);

			pokemon_staminas_view[x+2][y]=pokemon_staminas_view[x+2][y]-attack_power[area[x][y]];
			if(pokemon_staminas_view[x+2][y]<=0)
			{
				area[x+2][y]=-1;
				pokemon_staminas_view[x+2][y]=-1;
			}
		}

	}
	else if(type[area[x][y]]==linear&&range[area[x][y]]==2)
	{
		if(area[x][y-3]!=-1)
		{
			if(k%2==0)
			printf("You have attacked to    %s   \n !",Pokemon_name[area[x][y-3]]);
			else 
			printf("AI has attacked to your %s \n !",Pokemon_name[area[x][y-1]]);

			pokemon_staminas_view[x][y-3]=pokemon_staminas_view[x][y-3]-attack_power[area[x][y]];
			if(pokemon_staminas_view[x][y-3]<=0)
			{
				area[x][y-3]=-1;
				pokemon_staminas_view[x][y-3]=-1;
			}
		}
		if(area[x-3][y]!=-1)
		{
			if(k%2==0)
				printf("You have attacked to  %s \n !",Pokemon_name[area[x-3][y]]);
			else
			printf("AI has attacked to your   %s \n !",Pokemon_name[area[x][y-1]]);

			pokemon_staminas_view[x-3][y]=pokemon_staminas_view[x-3][y]-attack_power[area[x][y]];

			if(pokemon_staminas_view[x-3][y]<=0)
			{
				area[x-3][y]=-1;
				pokemon_staminas_view[x-3][y]=-1;
			}
		}
		if(area[x][y+3]!=-1)
		{
			if(k%2==0)
				printf("You have attacked to  %s \n !",Pokemon_name[area[x][y+3]]);
			else
			printf("AI has attacked to your   %s \n !",Pokemon_name[area[x][y-1]]);

			pokemon_staminas_view[x][y+3]=pokemon_staminas_view[x][y+3]-attack_power[area[x][y]];
			if(pokemon_staminas_view[x][y+3]<=0)
			{
				area[x][y+3]=-1;
				pokemon_staminas_view[x][y+3]=-1;
			}
		}
		if(area[x+3][y]!=-1)
		{
			if(k%2==0)
			printf("You have attacked to  			%s 	\n !",Pokemon_name[area[x+3][y]]);
			else
			printf("AI has attacked to your pokémon %s  \n !",Pokemon_name[area[x][y-1]]);

			pokemon_staminas_view[x+3][y]=pokemon_staminas_view[x+3][y]-attack_power[area[x][y]];

			if(pokemon_staminas_view[x+3][y]<=0)
			{
				area[x+3][y]=-1;
				pokemon_staminas_view[x+3][y]=-1;
			}
		}

	}
	/*-------------End----------------------------------*/
}
/*-------------StrCmp with Controlling '\0' character----------------------------------*/
int str_cmp(char *strA,char *strB)
{
	while(*strA==*strB&&*strB!='\0'&&*strA!='\0')
	{
		++strA;
		++strB;
	}
	return *strA-*strB;
}
void show_area (char Pokemon_name[][11],int area[][8],int pokemon_staminas_view[][8])
{
	int i=0,j=0,t=0,k=0;

	printf("\n");
	printf("       ");
	for(t=0 ; t<8 ; ++t)
		printf("(%d,%d)  ",0,t);

	printf("\n");

	for(i=0 ; i<8 ; ++i)
	{
		printf("     ");
		for(j=0 ; j<57 ; ++j) 
			printf("-");
		printf("\n");

		printf("(%d,%d)",i,0); 
		for(j=0 ; j<8 ; ++j)
		{
			if(area[i][j]==-1)  /* Controlling Empty or Not */
			printf("|      ");
			else
			printf("|   %.2s ",Pokemon_name[area[i][j]]);       
		}
		printf("|\n");
		printf("     ");

		for(j=0 ; j<8 ; ++j)
		{
			if(pokemon_staminas_view[i][j]==-1)  
			printf("|      ");
			else
			printf("|(%4d)",pokemon_staminas_view[i][j]);       
		}
		printf("|\n");

		if(i==7)
		{
			printf("     ");
			for(j=0 ; j<57 ; ++j) 
			printf("-");
			printf("\n");
		}
	}
	/*----------- Direction Arrows --------*/
	printf("\n");
	printf("\t\t\t  **Direction Arrows** \n\n"); 
	printf("\t\t\t  	   (1)\n");
	printf("\t\t\t  	   ↑\n");
	printf("\t\t\t  	   ↑\n");
	printf("\t\t\t  	   ↑\n");
	printf("\t\t\t  (2)← ← ← (5) → → →(4)\n");
	printf("\t\t\t  	   ↓\n");
	printf("\t\t\t  	   ↓\n");
	printf("\t\t\t  	   ↓\n");
	printf("\t\t\t  	   (3)\n");
}